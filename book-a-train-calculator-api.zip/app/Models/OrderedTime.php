<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderedTime extends Model
{
    protected $guarded = [];
}
