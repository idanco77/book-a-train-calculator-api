<?php

Route::post('email', 'OrderedTimeController@email');
